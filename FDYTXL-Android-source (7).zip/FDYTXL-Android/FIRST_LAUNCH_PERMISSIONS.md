# FDYTXL Android v1.4.0 — first-launch permissions

- On first install/update, the Android app shows a one-time welcome dialog BEFORE requesting any new permissions.
- It explains what notifications are intended to cover, sender-name-only Messenger previews, and the no-purchase/no-promotion policy.
- It explains approximate LOCATION is optional and is only used on demand for Weather. No precise or background location is requested.
- Both permissions can be skipped. Tap the Allow actions to trigger Android permission dialogs; no automatic jumps to Android Settings without explicit user interaction.
- FDYTXL Settings can open Android Notifications directly and FDYTXL App info -> Permissions -> Location, to change/revoke permissions.
- Granting Android notification permission DOES NOT automatically enable Firebase token/push. Users separately opt into Firebase in FDYTXL Settings.
- Never auto-subscribe everyone to the all-EPL scores Firebase topic. New secure server must read verified cloud favourites and opt-ins and route team events only to interested devices. Existing topic is unsubscribed on opt-in.
- Website favoured-team settings and text-only live score UI are already published and served in app WebView; no separate change is required to mirror the site.
- This ZIP builds the Android app only. Closed-app automatic sender is not deployed by uploading the Android source ZIP; follow Firebase backend deployment instructions separately.
- Android APK build may be signed with a different GitHub runner key than your installed APK; reinstall/backup if Android cannot update existing debug build.
