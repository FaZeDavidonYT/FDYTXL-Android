# FDYTXL v1.6: tap-to-match and scorer follow-ups

- Keep your first goal notification unchanged.
- A **second, separately displayed** `data.kind=scorer` push is supported for a confirmed scorer.
- Both native notifications use an event/league match-deep-link when provided by the secure FCM sender. Missing/invalid match references fall back to Live Scores Plus.
- Cold-start notifications open the match by honouring the validated FDYTXL intent URL in MainActivity.
- Android notification permissions, user push opt-in and public followed-team filters remain in place.
- Build updated ZIP as `FDYTXL-Android-source.zip` on your existing GitHub `FaZeDavidonYT-patch-1` workflow branch.
- Note: this source is not compiled in this environment; confirm green GitHub Actions build and install the new APK.
