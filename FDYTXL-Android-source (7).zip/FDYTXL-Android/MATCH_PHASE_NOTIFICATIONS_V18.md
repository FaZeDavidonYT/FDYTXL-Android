# FDYTXL Android v1.8 — match timeline notifications

Use this new source ZIP as `FDYTXL-Android-source.zip` in the existing `FaZeDavidonYT-patch-1` (default) branch of `FaZeDavidonYT/FDYTXL-Android`, then build and install the APK using the existing Actions workflow.

New push kind: `phase`, stages `pre15`, `kickoff`, `halftime`, `fulltime`. Every stage alert uses plain text and links to the correct match page, using the league and official match ID from the sender.

Receives stage pushes only if:
- Android notification permission and the FDYTXL Firebase toggle are enabled;
- The app has a locally verified signed-in account and Live Scores pass within 24 hours;
- The user follows at least one of the participating clubs in the correct competition.

Your existing v1.7 features remain: app icons, first-launch permission explanation, account-specific local display checks, website status notifications (shared status record, about 95 entries), opted-in approximate local 7am weather reminders with Weather Access, FA Cup/Carabao Cup, tap-to-open match goals, and the separate verified scorer follow-up message.

**The v1.8 APK alone cannot make the server send stages.** Deploy the paired Firebase Cloud Functions v1.8 ZIP in Google Cloud Shell. The scheduler runs about every five minutes, so 15-minute reminders are approximate and alerts can be delayed or missed. Public FCM topics must not be used for private/pass-protected content; this APK only implements on-device display gating, not server-side membership verification.
