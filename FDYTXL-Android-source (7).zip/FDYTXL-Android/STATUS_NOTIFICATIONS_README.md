FDYTXL v1.3.0: owner-set Website Server Status alerts (separate opt-in).
While FDYTXL is open, the existing Wix status-change record notifies the
Android app when changed; no alerts on initial load and no repeated polling alerts.
Opt-in is set under FDYTXL Settings > Android app permissions.
A new Firebase topic subscription is prepared, but secure server-side FCM
publishing is NOT deployed and must not be claimed functional.
The website status labels are manually set by the owner, not measured uptime.
Store purchases and promotions must not be sent by any future sender.
