# FDYTXL automatic notifications: setup roadmap, not yet deployed

1. Install FDYTXL v1.4.0 APK from your existing GitHub Actions workflow.
2. In Android, allow system notification permission, then opt into Background FDYTXL Firebase notifications inside Settings. Test sending a private Firebase Console notification to your own FCM token.
3. Connect your Firebase `fdytxl` project to a trusted backend. Use Firebase Admin SDK / FCM HTTP v1 from a secure server; do not store service-account JSON in the Android ZIP, Wix static site or public GitHub repo.
4. Backend must securely associate opt-in FCM device token with authenticated FDYTXL member identity; verify the member login server-side, respect opt-out and expired tokens, and protect personal data. The public site must never have permission to send arbitrary FCM messages.
5. The server should read members’ *followedTeams* from their member-private Wix `FDYTXLMemberPreferences.footballAlerts.followedTeams` list. Do not send a score push if neither club is followed. There is NO global EPL score broadcast topic for every app user.
6. Poll a properly licensed, trusted sports data provider. Create a persistent event/scores baseline, avoid duplicate sends, do not invent goal scorers, and send only verified score changes and scorer/minute if available. Cover football first, then other sports with separately confirmed feeds.
7. Use secure event notifications for gifts (confirmed founder grant records), Messenger (sender name from authorized member directory but NO encrypted message content), and owner-verified website status changes. Exclude purchases and marketing entirely.
8. Use FCM data-message payloads and Android-side opt-in checks. Use per-category preferences, rate limits, and privacy-preserving delivery. Verify app-closed delivery with physical devices and logs.
9. Scheduling/Cloud Functions or another hosted backend may require a billing-enabled account and possible costs; review pricing and seek responsible adult support before enabling billing. The GitHub APK build alone does not automatically send pushes.
