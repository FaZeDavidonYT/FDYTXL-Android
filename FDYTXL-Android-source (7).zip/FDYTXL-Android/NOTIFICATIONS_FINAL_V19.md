# FDYTXL Android v1.9 — final mobile delivery package

## What's new over v1.8

Allowing notifications in FDYTXL's native first-launch dialog or using its Android Settings permission button now activates Firebase background opt-in as well. It uses only explicitly followed-team topics and website status if the signed-in user has the locally checked Free Pass. People can turn this off under FDYTXL Settings or Android system settings. Denial never opts in. Explicitly disabling status alerts remains respected. Signing out suspends subscriptions, and changing account removes old account team follows; consent can resume for an eligible new account.

This preserves v1.8 match phases (kickoff ~15 min reminder, kickoff, half-time and full-time), FA Cup / Carabao Cup, delayed verified scorer, match deep links, website status (95 entries) and optional around 07:00 Weather reminders.

**Security limitation:** locally synced pass checks are not cryptographically verified by the Firebase sender. FCM topics are public; server-side entitlement verification and targeted private tokens are required before using topics for confidential or paid private data. Messenger and gift alerts are not enabled.

## Installation

Upload the ZIP *named exactly* `FDYTXL-Android-source.zip` to the repository root on `FaZeDavidonYT-patch-1`, replacing the original. The GitHub Android build workflow generates the APK; download its artifact, extract it and install `app-debug.apk`. New native features require this APK. Website assets may update automatically.
