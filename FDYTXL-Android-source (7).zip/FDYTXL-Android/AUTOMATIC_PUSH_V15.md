# FDYTXL Automatic Notification Client (v1.5)

This APK still preserves the original coloured app icon, white notification symbol, Firebase config and user-controlled permission dialogs.

When a signed-in FDYTXL member follows or unfollows clubs on the website, the authenticated page sends only public **league/team IDs** over the Android-origin-restricted WebView bridge in small chunks. On opt-in, Android subscribes to Firebase topics for those clubs, and unsubscribes from removed ones.

**No member name, Firebase device token, message text or account password is transmitted by this bridge.** A member who does not opt into background Firebase receives no automatic pushes. The website and local app must both be up-to-date to synchronize favourites.

The Cloud Function is a separate deployable project. Building the APK does not deploy the server.

The server must send data-only FCM for filtering to work. Messenger/gift private notifications need an additional authenticated member-to-device backend; they are not implemented by public football topics.
