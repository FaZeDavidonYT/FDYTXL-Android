package com.fdytxl.android;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.app.PendingIntent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.content.SharedPreferences;
import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.Locale;

/** Uses saved, user-selected city only: does not access GPS in background. */
public final class FDYTXLWeatherWorker extends Worker {
    public FDYTXLWeatherWorker(@NonNull Context context,@NonNull WorkerParameters params){super(context,params);}
    @NonNull @Override public Result doWork(){
        Context ctx=getApplicationContext();
        try{
            SharedPreferences p=ctx.getSharedPreferences(FDYTXLWeatherSchedule.PREF,Context.MODE_PRIVATE);
            if(!p.getBoolean("enabled",false)||!FDYTXLNativeEligibility.allowed(ctx,"weather"))return Result.success();
            String day=LocalDate.now().toString();
            if(day.equals(p.getString("lastShownDay","")))return Result.success();
            if(Build.VERSION.SDK_INT>=33 && ContextCompat.checkSelfPermission(ctx,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return Result.success();
            if(!NotificationManagerCompat.from(ctx).areNotificationsEnabled())return Result.success();
            double lat=Double.longBitsToDouble(p.getLong("lat",0)),lon=Double.longBitsToDouble(p.getLong("lon",0));
            if(lat< -90||lat>90||lon< -180||lon>180)return Result.failure();
            String city=p.getString("city","");if(city.isEmpty())return Result.failure();
            String endpoint=String.format(Locale.US,"https://api.open-meteo.com/v1/forecast?latitude=%.3f&longitude=%.3f&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=1",lat,lon);
            HttpURLConnection connection=null;
            try{
                connection=(HttpURLConnection)new URL(endpoint).openConnection();
                connection.setConnectTimeout(7000);connection.setReadTimeout(7000);
                connection.setRequestProperty("Accept","application/json");
                if(connection.getResponseCode()!=200)return Result.success();
                ByteArrayOutputStream out=new ByteArrayOutputStream();
                try(InputStream input=connection.getInputStream()){
                    byte[] buffer=new byte[2048];int n;while((n=input.read(buffer))!=-1){
                        out.write(buffer,0,n);if(out.size()>18000)return Result.failure();
                    }
                }
                JSONObject d=new JSONObject(new String(out.toByteArray(),StandardCharsets.UTF_8)).getJSONObject("daily");
                int w=d.getJSONArray("weather_code").getInt(0);
                int high=(int)Math.round(d.getJSONArray("temperature_2m_max").getDouble(0));
                int low=(int)Math.round(d.getJSONArray("temperature_2m_min").getDouble(0));
                String condition=w==0?"Clear":w<4?"Cloudy":w<50?"Hazy":w<70?"Rain":w<80?"Snow":w<90?"Showers":"Storms";
                String body=condition+" · "+low+"–"+high+"°C today · Weather: Open-Meteo.com";
                String ch="fdytxl_daily_weather";
                if(Build.VERSION.SDK_INT>=26){NotificationChannel channel=new NotificationChannel(ch,"FDYTXL Daily Weather",NotificationManager.IMPORTANCE_DEFAULT);
                    ((NotificationManager)ctx.getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(channel);}
                Intent intent=new Intent(ctx,MainActivity.class).setAction(Intent.ACTION_VIEW)
                    .setData(Uri.parse("https://fdytxl-fdytxl-0606.wix-site-host.com/weather.html"));
                PendingIntent tap=PendingIntent.getActivity(ctx,18204,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
                NotificationCompat.Builder b=new NotificationCompat.Builder(ctx,ch)
                    .setSmallIcon(R.drawable.ic_stat_fdytxl).setContentTitle("FDYTXL Weather · "+city)
                    .setContentText(body).setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                    .setAutoCancel(true).setContentIntent(tap);
                NotificationManagerCompat.from(ctx).notify(18204,b.build());
                p.edit().putString("lastShownDay",day).apply();
            }finally{if(connection!=null)connection.disconnect();}
        }catch(Exception ignored){/* Weather is optional. No empty, guessed or insecure forecast pushes. */}
        return Result.success();
    }
}
