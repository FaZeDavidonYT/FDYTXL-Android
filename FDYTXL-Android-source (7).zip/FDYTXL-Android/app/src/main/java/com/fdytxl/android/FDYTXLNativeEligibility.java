package com.fdytxl.android;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import java.util.Collections;

/** Account-specific local notification DISPLAY gate. Not a server-side access token. */
final class FDYTXLNativeEligibility {
    private static final String KEY="fdytxl_notification_access_v17";
    private FDYTXLNativeEligibility(){}
    static boolean allowed(Context ctx,String kind){
        SharedPreferences p=ctx.getSharedPreferences(KEY,Context.MODE_PRIVATE);
        String member=p.getString("member","");
        if(member.isEmpty())return false;
        long verified=p.getLong("updated",0);
        // Never trust an ancient entitlement after account access could have expired.
        if(verified<=0||System.currentTimeMillis()-verified>24L*60*60*1000)return false;
        if("weather".equals(kind))return p.getBoolean("weather",false);
        if("score".equals(kind)||"scorer".equals(kind)||"phase".equals(kind))return p.getBoolean("liveScores",false);
        if("status".equals(kind))return p.getBoolean("freePass",false);
        return false;
    }
    static void update(Context ctx,String member,boolean freePass,boolean liveScores,boolean weather){
        SharedPreferences p=ctx.getSharedPreferences(KEY,Context.MODE_PRIVATE);
        String old=p.getString("member","");
        if(member==null||!member.matches("[a-zA-Z0-9-]{6,80}"))member="";
        boolean changed=!old.equals(member);
        if(member.isEmpty()){
            p.edit().clear().apply();
            FDYTXLWeatherSchedule.disable(ctx);
            return;
        }
        p.edit().putString("member",member).putBoolean("freePass",freePass)
            .putBoolean("liveScores",liveScores).putBoolean("weather",weather)
            .putLong("updated",System.currentTimeMillis()).apply();
        if(changed){FDYTXLWeatherSchedule.disable(ctx);}
        else FDYTXLWeatherSchedule.schedule(ctx);
    }
}
