package com.fdytxl.android;

import java.util.Set;
import android.content.Context;

/** Topic subscription identifiers correspond to verified league/team IDs, never device identity. */
public final class FDYTXLFootballTopics {
    private FDYTXLFootballTopics(){}
    public static String topic(String league,String id){
        if(league==null||id==null||!league.matches("[A-Za-z0-9.]{2,35}")||!id.matches("[A-Za-z0-9._-]{1,55}"))return "";
        return "fdytxl_football_"+league.replace('.','_')+"_"+id;
    }
    public static boolean match(Context context,String league,String homeId,String awayId){
        Set<String> topics=context.getSharedPreferences("fdytxl_followed_fcm_topics_v15",Context.MODE_PRIVATE)
             .getStringSet("topics",java.util.Collections.emptySet());
        String home=topic(league,homeId),away=topic(league,awayId);
        return (!home.isEmpty()&&topics.contains(home))||(!away.isEmpty()&&topics.contains(away));
    }
}
