package com.fdytxl.android;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import java.time.Duration;
import java.time.ZonedDateTime;
import java.util.concurrent.TimeUnit;

/** Opt-in 7am LOCAL-TIME best-effort daily Weather WorkManager task. */
final class FDYTXLWeatherSchedule {
    static final String PREF="fdytxl_weather_alerts_v17",WORK="fdytxl_weather_daily_7am";
    private FDYTXLWeatherSchedule(){}
    static void disable(Context ctx){
        ctx.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().clear().apply();
        WorkManager.getInstance(ctx).cancelUniqueWork(WORK);
    }
    static void set(Context ctx,boolean enable,String city,double lat,double lon){
        if(!enable){disable(ctx);return;}
        if(!FDYTXLNativeEligibility.allowed(ctx,"weather")||city==null||city.length()>65||
           city.trim().isEmpty()||!Double.isFinite(lat)||!Double.isFinite(lon)||
           lat< -90||lat>90||lon< -180||lon>180){disable(ctx);return;}
        ctx.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putBoolean("enabled",true)
           .putString("city",city.trim()).putLong("lat",Double.doubleToLongBits(lat))
           .putLong("lon",Double.doubleToLongBits(lon)).apply();
        schedule(ctx);
    }
    static void schedule(Context ctx){
        SharedPreferences p=ctx.getSharedPreferences(PREF,Context.MODE_PRIVATE);
        if(!p.getBoolean("enabled",false))return;
        if(!FDYTXLNativeEligibility.allowed(ctx,"weather")){
            WorkManager.getInstance(ctx).cancelUniqueWork(WORK);return;
        }
        ZonedDateTime now=ZonedDateTime.now();
        ZonedDateTime next=now.withHour(7).withMinute(0).withSecond(0).withNano(0);
        if(!next.isAfter(now))next=next.plusDays(1);
        long millis=Math.max(1000,Duration.between(now,next).toMillis());
        PeriodicWorkRequest job=new PeriodicWorkRequest.Builder(FDYTXLWeatherWorker.class,24,TimeUnit.HOURS)
                .setInitialDelay(millis,TimeUnit.MILLISECONDS).build();
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(WORK,ExistingPeriodicWorkPolicy.UPDATE,job);
    }
}
