# FDYTXL branded Android app — version 1.2.0

This is Android SOURCE, not an APK. It must be uploaded as `FDYTXL-Android-source.zip` in the GitHub repository patch branch and compiled through GitHub Actions.

Changes from Firebase v1.1.0:
- User-selected first image as the launcher icon across screen densities.
- User-selected second transparent white mark as the native and Firebase notification icon, used for all Android notification channels.
- Native football scores are plain text: `Liverpool 1–0 Manchester United`, followed by a supplied scorer/minute where available. No custom scoreboard image.
- Generic notifications continue to have text-only bodies and use the new icon.
- FCM background notification-payload messages use the manifest default icon; data-only football alerts are rendered by the Firebase service.
- Scorer names are **not fabricated**: provider/API or sender must supply the scorer in the `detail` field; otherwise an honest fallback is shown.
- Original Firebase registration/token/opt-in and website WebView behaviours preserved.
- App versionCode 3, versionName 1.2.0.

This change does not deploy a real-time football score push server. Existing tested Firebase Console background notifications should continue to work after updating and enabling notifications.

To build: replace root `FDYTXL-Android-source.zip` on branch `FaZeDavidonYT-patch-1`. Wait for a green workflow, download artifact `FDYTXL-Android-Firebase-APK`, extract `app-debug.apk`, install. A changed debug signing key can require uninstall and data loss, so do not uninstall until necessary.
