# FDYTXL Android app — source and APK cloud build

This is a **real Android app source project** wrapping the existing official FDYTXL site. It is **not a compiled or signed APK**. No Android SDK or Gradle build environment was available in this chat. The APK itself was not built.


## Build your FDYTXL APK online (computer not required)

This ZIP contains the GitHub Actions build workflow at `.github/workflows/build-fdytxl-apk.yml`. It is *configured*, but **has not been run or verified against a real Android SDK**.

1. Create a **private GitHub repository** that you control.
2. Extract this ZIP and place the contents of **FDYTXL-Android** at the GitHub repository root, including the hidden `.github` directory. Do not upload just the ZIP expecting GitHub to extract it.
3. Open the repository **Actions** tab, select **Build FDYTXL Android APK** and choose **Run workflow**. Allow the build to complete.
4. When the build is successful, open its run and download the **FDYTXL-Android-debug-APK** artifact. GitHub supplies it as a ZIP containing `app-debug.apk`.
5. Test that debug APK on your own Android device. Debug builds are for testing, not public distribution. Do not trust or share APKs from unknown websites.

**App-closed/background football alerts remain unconfigured** and need an authenticated backend and push service. Notification and approximate location permissions remain user-initiated and optional. Do not place passwords or service-account secrets into the public app.

## What works after building

- Launches `https://fdytxl-fdytxl-0606.wix-site-host.com/` as the FDYTXL app.
- Secure same-origin navigation and modern Android WebView.
- On Android 13+, the FDYTXL notification permission is requested **only after a user taps Allow Android notifications in Website Settings**.
- Distinct Android notification channels for FDYTXL Live Football and FDYTXL Website.
- Branded expanded Android football scorecards with native notification layout: FDYTXL header, both teams, actual scores and LIVE/FULL TIME badge. The collapsed notification contains the same match result and opens the match page. Updates only occur when the website detects a real score change while it is open and the user has opted in.
- Approximate location via `ACCESS_COARSE_LOCATION` only; triggered by `Weather > Use my location`, never on launch or in the background.
- Does not request microphone, camera, contacts, background location, exact alarms, or file-system permissions.

## How to build an APK

1. Install Android Studio with the Android SDK (compile SDK 36) on a computer.
2. Open this `FDYTXL-Android` directory as a project.
3. Android Studio should offer to download Gradle and the project's AndroidX dependencies. If necessary, select **Sync Project with Gradle Files**.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The output should be at `app/build/outputs/apk/debug/app-debug.apk`.
5. Android devices may warn that debug builds are not store-signed. For public distribution, create a secure release keystore and sign your release APK in Android Studio. Do not distribute a debug APK as a trusted production update.
6. **App icon:** Replace the default system placeholder icon with your actual FDYTXL official logo using Image Asset Studio before distributing. Your site itself displays the official existing logo. No third-party/replacement logo has been generated here.

### Important limitations

- This Android WebView wrapper does **not** receive background Firebase Cloud Messaging pushes or real-time goal alerts while the app is closed. Those need a separate push backend with consent, securely managed Firebase credentials and event scheduling.
- Android APK converters that do not support a secure native message bridge will still show the **in-site notification designs**, but not system notifications.
- You need to try app auth/login and cross-site sign-in flows on a real Android device. External sign-in destinations open in the phone's browser.
- Data use: there is no background location collection. Weather receives approximate rounded coordinates when the user requests the weather near them. FDYTXL website membership and private account data remain hosted on Wix.
- Location and notification permissions can always be revoked from Android App Info > Permissions.
- The APK app identity `com.fdytxl.android` is a proposed new package name; check uniqueness before publishing.
- There is no Firebase project linked yet. Do not paste Firebase service-account credentials into your app or browser JavaScript.
- The project contains no `gradle-wrapper.jar` or binary dependencies; they must be installed by Android Studio/Gradle during sync.
