# FDYTXL Firebase Messaging — Android version 1.1.0

**Package** `com.fdytxl.android` — **Firebase project** `fdytxl`.

This archive is a source-code update, **not a compiled APK**. GitHub Actions is required to compile and install it; it has not been compiled or tested here.

## What is implemented

- Firebase Gradle configuration (`google-services` 4.5.0 and Firebase BoM 35.0.2).
- Your `google-services.json` inside `app/`. This Firebase client configuration contains non-secret project identifiers. Never add service-account private keys or HTTP v1 credentials to Android source.
- FCM service for foreground message handling, including FDYTXL-branded score notifications for `data.kind = score`.
- Android system-tray notifications for FCM notification-payload messages while app is in the background are handled by the Firebase SDK.
- On-demand FCM registration, permission check, opt-in and opt-out, `fdytxl_eng1_scores` topic subscription.
- `push-on`, `push-off`, `push-token` messages on the existing origin-restricted native bridge.
- Copy FCM device token via Android dialog; it is **never logged, auto-sent to the website, or copied to this chat**.

## How to rebuild using your Android phone

1. In GitHub, open `FaZeDavidonYT/FDYTXL-Android`, select branch `FaZeDavidonYT-patch-1` (the branch with your green Actions build).
2. Upload the new archive `FDYTXL-Android-source.zip` and **replace the old same-name file on that branch**, preserving `.github/workflows/build.yml`. If GitHub's mobile interface does not let you replace the existing ZIP, rename the new file to a new filename and change the `unzip` command in the workflow to that exact filename.
3. The workflow should run on push. Verify the new run is green and that the debug APK artifact exists.
4. Download the artifact ZIP; extract the actual `app-debug.apk`.
5. Your existing debug APK may be signed by a *different* random GitHub runner signing key. If Android reports an incompatible update, the old debug APK must be uninstalled before you can install this new debug build, which will remove local app storage and signed-in session. Back up any necessary app-only data before uninstalling. A permanent signing key kept private would be needed for seamless updates.

## One-device closed-app test

1. In the newly installed app visit FDYTXL **Settings → Android app permissions**.
2. Enable local Android notifications and **Background football notifications (Firebase)**. Accept Android's notification permission.
3. Tap **Copy Firebase test token**. The native Android popup copies it to your clipboard privately; do not paste it into GitHub or public chats.
4. Open Firebase Console → your `fdytxl` project → Messaging → create a Notification campaign → Send test message and paste the token.
5. Background the app by pressing Home (do not force-stop it), then send the test. You should see the test notification in Android's system notification tray. Ensure the device has Google Play services and internet access.

## Limits and next step

**No automatic real-match closed-app sender has been deployed.** This version can *receive* FCM pushes but a trusted 24/7 server is still needed to poll a real football data source, compare actual scores, deduplicate goal events and send signed Firebase Admin SDK notifications to `fdytxl_eng1_scores`. Implement/host that server separately, with private credentials and responsible quotas. No fake/test scores should ever be published as genuine.

**Do not confuse your Liverpool (TEST) vs Man United (TEST) owner-only webpage simulation with Firebase server pushes.** The test page produces local app-open events only. If you want to simulate closed-app pushes, do so with a private test campaign targeting only your device's token, never the live football topic.

Docs: https://firebase.google.com/docs/cloud-messaging/android/get-started
https://firebase.google.com/docs/cloud-messaging/android/receive-messages
