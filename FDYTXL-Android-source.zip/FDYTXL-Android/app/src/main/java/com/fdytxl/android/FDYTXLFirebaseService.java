package com.fdytxl.android;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.Map;

/**
 * Handles foreground FCM and DATA-ONLY background FCM messages.
 * Firebase automatically displays notification-payload messages when backgrounded;
 * we deliberately don't duplicate those notifications here.
 */
public class FDYTXLFirebaseService extends FirebaseMessagingService {
    private static final String SCORE_CHANNEL="fdytxl_live_scores";

    @Override public void onMessageReceived(RemoteMessage message) {
        if(!getSharedPreferences("fdytxl_native_push",MODE_PRIVATE).getBoolean("push_enabled",false)) return;
        Map<String,String> data=message.getData();
        String home=shortText(data.get("home"),42);
        String away=shortText(data.get("away"),42);
        String scorer=shortText(data.get("detail"),70);
        String kind=data.get("kind");
        String phase="FT".equals(data.get("phase"))?"FT":"LIVE";
        int hs=scoreInt(data.get("homeScore")),as=scoreInt(data.get("awayScore"));
        if("score".equals(kind)&&!home.isEmpty()&&!away.isEmpty()&&hs>=0&&as>=0){
            // Data-only background pushes: never show an unfollowed team.
            if(!FDYTXLFootballTopics.match(this,shortText(data.get("league"),40),
                       shortText(data.get("homeTeamId"),55),shortText(data.get("awayTeamId"),55)))return;
            String eventId=shortText(data.get("eventId"),150);
            if(eventId.length()<5)return;
            String recent=getSharedPreferences("fdytxl_native_push",MODE_PRIVATE).getString("last_fcm_goal","");
            if(eventId.equals(recent))return;
            renderScore(home,away,hs,as,scorer,phase);
            getSharedPreferences("fdytxl_native_push",MODE_PRIVATE).edit().putString("last_fcm_goal",eventId).apply();
            return;
        }
        if("status".equals(kind)){
            if(!getSharedPreferences("fdytxl_native_push",MODE_PRIVATE).getBoolean("status_enabled",false))return;
            String state=shortText(data.get("state"),12);
            if(!("up".equals(state)||"issues".equals(state)||"down".equals(state)))return;
            String siteName=shortText(data.get("service"),58);
            if(siteName.isEmpty())siteName="FDYTXL Website";
            String label="up".equals(state)?"Fully Up and Running":"issues".equals(state)?"Experiencing Issues":"Temporarily Down";
            renderWebsiteStatus(siteName+" is now "+label+".",shortText(data.get("eventId"),170));
            return;
        }
        if(message.getNotification()!=null){
            String title=shortText(message.getNotification().getTitle(),70);
            String body=shortText(message.getNotification().getBody(),160);
            showGeneric(title.isEmpty()?"FDYTXL":title,body);
        }
    }

    @Override public void onNewToken(String token) {
        // No token is logged or sent to the website.
        // The user may copy the current token locally from FDYTXL Settings.
    }

    private static String shortText(String s,int max){
        if(s==null)return "";
        s=s.replaceAll("[\\p{Cntrl}]"," ").trim();
        return s.length()>max?s.substring(0,max):s;
    }
    private static int scoreInt(String val){
        try{int n=Integer.parseInt(val);return n>=0&&n<=99?n:-1;}catch(Exception e){return -1;}
    }
    private void ensureChannel(){
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel channel=new NotificationChannel(SCORE_CHANNEL,"FDYTXL Live Football",NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Opt-in real football score updates and FCM test notifications");
            NotificationManager nm=getSystemService(NotificationManager.class);
            if(nm!=null)nm.createNotificationChannel(channel);
        }
    }
    private PendingIntent openScores(){
        Intent intent=new Intent(this,MainActivity.class);
        intent.setAction(Intent.ACTION_VIEW);
        intent.setData(Uri.parse("https://fdytxl-fdytxl-0606.wix-site-host.com/scores-plus.html"));
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(this,17011,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    private void renderScore(String home,String away,int hs,int as,String scorer,String phase){
        ensureChannel();
        // No score picture: Android renders title + scorer/minute as plain text.
        String title=home+" "+hs+"–"+as+" "+away;
        String body="FT".equals(phase)?"Full time"+(scorer.isEmpty()?"":" • "+scorer)
              :scorer.isEmpty()?"Goal / score update • Scorer unavailable":scorer;
        NotificationCompat.Builder notice=new NotificationCompat.Builder(this,SCORE_CHANNEL)
          .setSmallIcon(R.drawable.ic_stat_fdytxl)
          .setColor(Color.rgb(232,49,93))
          .setContentTitle(title)
          .setContentText(body)
          .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
          .setPriority(NotificationCompat.PRIORITY_DEFAULT)
          .setContentIntent(openScores())
          .setAutoCancel(true);
        try{NotificationManagerCompat.from(this).notify((home+away+hs+as).hashCode(),notice.build());}catch(SecurityException ignored){}
    }
    private void renderWebsiteStatus(String body,String id){
        if(id.isEmpty())return;
        String old=getSharedPreferences("fdytxl_native_push",MODE_PRIVATE).getString("last_status_event","");
        if(id.equals(old))return;
        getSharedPreferences("fdytxl_native_push",MODE_PRIVATE).edit().putString("last_status_event",id).apply();
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel channel=new NotificationChannel("fdytxl_updates","FDYTXL Website",NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager nm=getSystemService(NotificationManager.class);
            if(nm!=null)nm.createNotificationChannel(channel);
        }
        Intent intent=new Intent(this,MainActivity.class);
        intent.setAction(Intent.ACTION_VIEW);
        intent.setData(Uri.parse("https://fdytxl-fdytxl-0606.wix-site-host.com/website-server-status.html"));
        PendingIntent open=PendingIntent.getActivity(this,17012,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder notice=new NotificationCompat.Builder(this,"fdytxl_updates")
          .setSmallIcon(R.drawable.ic_stat_fdytxl).setColor(Color.rgb(232,49,93))
          .setContentTitle("FDYTXL Website Server Status").setContentText(body)
          .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
          .setAutoCancel(true).setContentIntent(open);
        try{NotificationManagerCompat.from(this).notify(id.hashCode(),notice.build());}catch(SecurityException ignored){}
    }
    private void showGeneric(String title,String body){
        ensureChannel();
        NotificationCompat.Builder notice=new NotificationCompat.Builder(this,SCORE_CHANNEL)
          .setSmallIcon(R.drawable.ic_stat_fdytxl).setColor(Color.rgb(232,49,93))
          .setContentTitle(title).setContentText(body)
          .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
          .setAutoCancel(true).setContentIntent(openScores());
        try{NotificationManagerCompat.from(this).notify(991314,notice.build());}catch(SecurityException ignored){}
    }
}
