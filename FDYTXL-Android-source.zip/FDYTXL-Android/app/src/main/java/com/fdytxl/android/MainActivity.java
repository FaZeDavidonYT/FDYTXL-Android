package com.fdytxl.android;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.Context;
import android.content.ClipboardManager;
import android.content.ClipData;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.GeolocationPermissions;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.net.http.SslError;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;
import com.google.firebase.messaging.FirebaseMessaging;

import org.json.JSONObject;
import java.util.Collections;

public class MainActivity extends Activity {
    private static final String ORIGIN = "https://fdytxl-fdytxl-0606.wix-site-host.com";
    private static final int REQ_NOTIFICATION=501, REQ_LOCATION=502;
    private static final String SCORES="fdytxl_live_scores", GENERAL="fdytxl_updates";
    private WebView web;
    private ProgressBar loading;
    private GeolocationPermissions.Callback geoCallback;
    private String geoOrigin;
    private boolean pendingPushPermission=false;
    private boolean onboardingNotificationRequest=false;
    private static final String WELCOME_PREFS="fdytxl_welcome_permissions_v14";
    private static final String PUSH_PREFS="fdytxl_native_push";
    static final String PUSH_TOPIC="fdytxl_eng1_scores";
    static final String STATUS_TOPIC="fdytxl_website_status";

    @SuppressLint("SetJavaScriptEnabled")
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(Color.rgb(16, 12, 18));
        getWindow().setNavigationBarColor(Color.rgb(16, 12, 18));
        FrameLayout root = new FrameLayout(this);
        web = new WebView(this);
        loading = new ProgressBar(this);
        FrameLayout.LayoutParams spinner = new FrameLayout.LayoutParams(120,120,Gravity.CENTER);
        root.addView(web,new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(loading, spinner);
        setContentView(root);
        makeChannels();
        // Existing opt-in is stored on this device; no FCM registration by default.
        if(getSharedPreferences(PUSH_PREFS,MODE_PRIVATE).getBoolean("push_enabled",false)){
            FirebaseMessaging.getInstance().setAutoInitEnabled(true);
            // Do not auto-subscribe every member to an all-teams score topic.
            // Future score push must target users whose cloud favourite teams match.
            if(getSharedPreferences(PUSH_PREFS,MODE_PRIVATE).getBoolean("status_enabled",false))
                FirebaseMessaging.getInstance().subscribeToTopic(STATUS_TOPIC);
        }

        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setGeolocationEnabled(true);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSupportMultipleWindows(false);
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O) s.setSafeBrowsingEnabled(true);
        android.webkit.CookieManager.getInstance().setAcceptCookie(true);

        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request){
                Uri uri=request.getUrl();
                if(isOurs(uri))return false;
                if("https".equals(uri.getScheme()) || "mailto".equals(uri.getScheme())){
                    try{startActivity(new Intent(Intent.ACTION_VIEW,uri));}catch(Exception ignored){}
                }
                return true;
            }
            @Override public void onPageFinished(WebView view,String url){loading.setVisibility(View.GONE);}
            @Override public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error){handler.cancel();}
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public void onGeolocationPermissionsShowPrompt(String origin,GeolocationPermissions.Callback callback){
                // Only the FDYTXL weather website can ask for foreground approximate location.
                if(!ORIGIN.equals(origin)){callback.invoke(origin,false,false);return;}
                if(ContextCompat.checkSelfPermission(MainActivity.this,Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED){
                    callback.invoke(origin,true,false);return;
                }
                if(geoCallback!=null){geoCallback.invoke(geoOrigin,false,false);}
                geoCallback=callback;geoOrigin=origin;
                requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},REQ_LOCATION);
            }
            @Override public void onGeolocationPermissionsHidePrompt(){
                geoCallback=null;geoOrigin=null;
            }
        });
        // AndroidX WebMessageListener is restricted to this HTTPS origin and main frame.
        // Unlike addJavascriptInterface, an untrusted iframe cannot request notifications.
        if(WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)){
            WebViewCompat.addWebMessageListener(web,"FDYTXLAndroid",Collections.singleton(ORIGIN),
              (view,message,sourceOrigin,isMainFrame,reply)->{
                if(!isMainFrame || !ORIGIN.equals(sourceOrigin.toString()))return;
                String json=message.getData();
                if(json==null || json.length()>2500)return;
                runOnUiThread(()->handleSiteMessage(json));
              });
        }
        if(saved==null){
            web.loadUrl(ORIGIN + "/");
            // Explain optional permissions once on first launch. Never request permissions
            // or open Android settings until the person deliberately taps a button.
            web.postDelayed(this::showFirstLaunchPermissions,900);
        }else web.restoreState(saved);
    }
    private boolean isOurs(Uri uri){return "https".equals(uri.getScheme())&&"fdytxl-fdytxl-0606.wix-site-host.com".equals(uri.getHost());}
    private void handleSiteMessage(String data){
        try{
            JSONObject obj=new JSONObject(data);
            String type=obj.optString("type","");
            if("permission".equals(type)){askNotifications();return;}
            if("notification-settings".equals(type)){openNotificationSettings();return;}
            if("location-settings".equals(type)){openLocationSettings();return;}
            if("location-permission".equals(type)){explainLocationPermission();return;}
            if("permission-onboarding".equals(type)){showPermissionChoices();return;}
            if("test".equals(type)){
                if(canNotify()) notifyGeneral("FDYTXL • Demo notification","This is a DEMO notification, not a real football score.");
                else Toast.makeText(this,"Enable notifications in Android settings first",Toast.LENGTH_LONG).show();
                return;
            }
            if("push-on".equals(type)){setBackgroundPush(true);return;}
            if("push-off".equals(type)){setBackgroundPush(false);return;}
            if("push-token".equals(type)){showPushToken();return;}
            if("status-on".equals(type)){setStatusNotifications(true);return;}
            if("status-off".equals(type)){setStatusNotifications(false);return;}
            if("website-status".equals(type)){showWebsiteStatus(obj);return;}
            if("score".equals(type)) showScore(obj);
        }catch(Exception ignored){}
    }
    private void setBackgroundPush(boolean enabled){
        if(!enabled){
            getSharedPreferences(PUSH_PREFS,MODE_PRIVATE).edit().putBoolean("push_enabled",false).apply();
            // Unsubscribe older app versions from the broad EPL broadcast topic.
            FirebaseMessaging.getInstance().unsubscribeFromTopic(PUSH_TOPIC);
            FirebaseMessaging.getInstance().unsubscribeFromTopic(STATUS_TOPIC);
            FirebaseMessaging.getInstance().setAutoInitEnabled(false);
            FirebaseMessaging.getInstance().deleteToken();
            Toast.makeText(this,"FDYTXL background push switched off",Toast.LENGTH_LONG).show();
            return;
        }
        if(Build.VERSION.SDK_INT>=33 && ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
            pendingPushPermission=true;
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_NOTIFICATION);
            return;
        }
        activatePush();
    }
    private void activatePush(){
        if(!canNotify()){
            Toast.makeText(this,"Allow FDYTXL notifications in Android Settings first",Toast.LENGTH_LONG).show();
            return;
        }
        getSharedPreferences(PUSH_PREFS,MODE_PRIVATE).edit().putBoolean("push_enabled",true).apply();
        FirebaseMessaging.getInstance().setAutoInitEnabled(true);
        // Unsubscribe legacy broad league alerts: users must follow teams explicitly.
        FirebaseMessaging.getInstance().unsubscribeFromTopic(PUSH_TOPIC);
        if(getSharedPreferences(PUSH_PREFS,MODE_PRIVATE).getBoolean("status_enabled",false))
            FirebaseMessaging.getInstance().subscribeToTopic(STATUS_TOPIC);
        Toast.makeText(this,"FDYTXL Firebase ready. Automatic score delivery needs the secure team-favourites server.",Toast.LENGTH_LONG).show();
    }
    private void showPushToken(){
        if(!getSharedPreferences(PUSH_PREFS,MODE_PRIVATE).getBoolean("push_enabled",false)){
            new AlertDialog.Builder(this).setTitle("FDYTXL Firebase test")
              .setMessage("Switch on Background football push first in FDYTXL Settings.")
              .setPositiveButton("OK",(d,w)->{}).show();
            return;
        }
        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task->runOnUiThread(()->{
            if(!task.isSuccessful()||task.getResult()==null){
                new AlertDialog.Builder(this).setTitle("Firebase token unavailable")
                  .setMessage("Check your internet connection and Google Play services, then try again.")
                  .setPositiveButton("OK",(d,w)->{}).show();return;
            }
            String token=task.getResult();
            // Token stays inside the Android app and on the clipboard when the owner taps Copy.
            new AlertDialog.Builder(this).setTitle("FDYTXL Firebase test token")
              .setMessage("Copy this token into Firebase Console → Messaging → Send test message. Do not share it publicly.")
              .setPositiveButton("Copy token",(d,w)->{
                  ClipboardManager c=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                  if(c!=null)c.setPrimaryClip(ClipData.newPlainText("FDYTXL FCM token",token));
                  Toast.makeText(this,"FCM test token copied",Toast.LENGTH_SHORT).show();
              })
              .setNegativeButton("Cancel",(d,w)->{}).show();
        }));
    }
    private void setStatusNotifications(boolean enabled){
        getSharedPreferences(PUSH_PREFS,MODE_PRIVATE).edit().putBoolean("status_enabled",enabled).apply();
        boolean firebaseOn=getSharedPreferences(PUSH_PREFS,MODE_PRIVATE).getBoolean("push_enabled",false);
        if(!enabled){
            FirebaseMessaging.getInstance().unsubscribeFromTopic(STATUS_TOPIC);
            Toast.makeText(this,"Website status notifications off",Toast.LENGTH_SHORT).show();
        }else{
            if(firebaseOn) FirebaseMessaging.getInstance().subscribeToTopic(STATUS_TOPIC);
            Toast.makeText(this,firebaseOn?"Website status alerts enabled":"Website status alerts enabled while open. Enable Firebase background push for closed-app alerts.",Toast.LENGTH_LONG).show();
        }
    }
    private void showWebsiteStatus(JSONObject o){
        if(!getSharedPreferences(PUSH_PREFS,MODE_PRIVATE).getBoolean("status_enabled",false)||!canNotify())return;
        String state=o.optString("state","");
        if(!("up".equals(state)||"issues".equals(state)||"down".equals(state)))return;
        String eventId=o.optString("eventId","");
        if(eventId.length()<10||eventId.length()>170)return;
        String old=getSharedPreferences(PUSH_PREFS,MODE_PRIVATE).getString("last_status_event","");
        if(eventId.equals(old))return;
        String service=o.optString("service","FDYTXL Website");
        if(service.length()>58||service.isEmpty())service="FDYTXL Website";
        String label="up".equals(state)?"Fully Up and Running":"issues".equals(state)?"Experiencing Issues":"Temporarily Down";
        String message=service+" is now "+label+".";
        getSharedPreferences(PUSH_PREFS,MODE_PRIVATE).edit().putString("last_status_event",eventId).apply();
        NotificationCompat.Builder b=new NotificationCompat.Builder(this,GENERAL)
          .setSmallIcon(R.drawable.ic_stat_fdytxl).setColor(Color.rgb(232,49,93))
          .setContentTitle("FDYTXL Website Server Status")
          .setContentText(message)
          .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
          .setAutoCancel(true).setContentIntent(openLink("/website-server-status.html"));
        try{NotificationManagerCompat.from(this).notify(eventId.hashCode(),b.build());}catch(SecurityException ignored){}
    }
    private void showFirstLaunchPermissions(){
        if(isFinishing()||isDestroyed())return;
        boolean already=getSharedPreferences(WELCOME_PREFS,MODE_PRIVATE).getBoolean("explained",false);
        if(already)return;
        getSharedPreferences(WELCOME_PREFS,MODE_PRIVATE).edit().putBoolean("explained",true).apply();
        new AlertDialog.Builder(this)
          .setTitle("Welcome to FDYTXL")
          .setMessage("Make FDYTXL yours. Both permissions are optional.\n\n"
             +"NOTIFICATIONS\nLive scores for followed teams, gifts, Messenger sender names (never message text), and website status updates as services become available. No purchase or random promotional push alerts.\n\n"
             +"LOCATION\nApproximate location only, for local Weather when you choose 'Use my location'. No location tracking in the background.\n\n"
             +"You can decline either permission. Change or turn them off at any time in Android Settings → Apps → FDYTXL.")
          .setPositiveButton("Choose permissions",(d,w)->showNotificationChoice())
          .setNegativeButton("Not now",(d,w)->{})
          .setNeutralButton("Open Android settings",(d,w)->openAppSettings())
          .show();
    }
    private void showPermissionChoices(){
        new AlertDialog.Builder(this)
          .setTitle("FDYTXL permissions")
          .setMessage("Notifications are for followed-team scores, gifts, Messenger sender-only alerts and website status. Approximate location is optional for Weather.\n\nYou can skip both and revoke them at any time through Android Settings. Background score alerts need a separate opt-in and secure Firebase sender.")
          .setPositiveButton("Choose permissions",(d,w)->showNotificationChoice())
          .setNeutralButton("Android app settings",(d,w)->openAppSettings())
          .setNegativeButton("Cancel",(d,w)->{})
          .show();
    }
    private void showNotificationChoice(){
        new AlertDialog.Builder(this)
          .setTitle("Allow FDYTXL notifications?")
          .setMessage("Receive the alerts you choose: favourite-team football scores, gifts, who sent you a Messenger message (never the actual message), and owner-set website status.\n\nAndroid permission alone does not enable Firebase background push; you can opt into that separately inside FDYTXL Settings. Notifications can be turned off any time.")
          .setPositiveButton("Allow notifications",(d,w)->{
              if(canNotify()){Toast.makeText(this,"Notifications already allowed",Toast.LENGTH_SHORT).show();showLocationChoice();}
              else if(Build.VERSION.SDK_INT>=33){
                  onboardingNotificationRequest=true;
                  requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_NOTIFICATION);
              }else{openNotificationSettings();showLocationChoice();}
          })
          .setNegativeButton("Skip",(d,w)->showLocationChoice())
          .show();
    }
    private void showLocationChoice(){
        new AlertDialog.Builder(this)
          .setTitle("Allow approximate location for Weather?")
          .setMessage("Optional: FDYTXL Weather can show local conditions when you tap 'Use my location'. FDYTXL asks for approximate location only, and uses it while the app is open—not in the background.\n\nYou can skip this or turn it off any time in Android Settings.")
          .setPositiveButton("Allow approximate location",(d,w)->requestLocationPermission())
          .setNegativeButton("Skip",(d,w)->{})
          .show();
    }
    private void explainLocationPermission(){
        new AlertDialog.Builder(this)
          .setTitle("FDYTXL Weather location")
          .setMessage("Approximate, foreground-only location helps FDYTXL Weather show nearby conditions after you tap 'Use my location'. It is optional and you can revoke it any time. You can also search for a location manually.")
          .setPositiveButton("Allow location",(d,w)->requestLocationPermission())
          .setNeutralButton("Location settings",(d,w)->openLocationSettings())
          .setNegativeButton("Cancel",(d,w)->{})
          .show();
    }
    private void requestLocationPermission(){
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED){
            Toast.makeText(this,"Approximate location already allowed",Toast.LENGTH_SHORT).show();
        }else requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},REQ_LOCATION);
    }
    private void openAppSettings(){
        try{startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())));}
        catch(Exception ignored){Toast.makeText(this,"Open Android Settings > Apps > FDYTXL",Toast.LENGTH_LONG).show();}
    }
    private void openNotificationSettings(){
        try{
            if(Build.VERSION.SDK_INT>=26){
                Intent intent=new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                intent.putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName());
                startActivity(intent);
            }else openAppSettings();
        }catch(Exception e){openAppSettings();}
    }
    private void openLocationSettings(){
        // No universal supported deep link to a particular app's Location permission.
        // Open FDYTXL App info, then the user selects Permissions > Location.
        new AlertDialog.Builder(this).setTitle("FDYTXL location settings")
          .setMessage("On the next Android screen, tap Permissions → Location. You can allow or deny location here at any time.")
          .setPositiveButton("Open FDYTXL app settings",(d,w)->openAppSettings())
          .setNegativeButton("Cancel",(d,w)->{})
          .show();
    }
    private void askNotifications(){
        if(Build.VERSION.SDK_INT>=33 && ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_NOTIFICATION);
        }else Toast.makeText(this,"Notification setting is controlled by Android",Toast.LENGTH_SHORT).show();
    }
    private boolean canNotify(){
        return (Build.VERSION.SDK_INT<33||ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED)
               &&NotificationManagerCompat.from(this).areNotificationsEnabled();
    }
    private void makeChannels(){
        if(Build.VERSION.SDK_INT>=26){
            NotificationManager manager=getSystemService(NotificationManager.class);
            NotificationChannel score=new NotificationChannel(SCORES,"FDYTXL Live Football",NotificationManager.IMPORTANCE_DEFAULT);
            score.setDescription("Real score changes detected while FDYTXL is open");
            NotificationChannel other=new NotificationChannel(GENERAL,"FDYTXL Website",NotificationManager.IMPORTANCE_DEFAULT);
            other.setDescription("Opt-in FDYTXL app test and website notifications");
            manager.createNotificationChannel(score);manager.createNotificationChannel(other);
        }
    }
    private PendingIntent openLink(String relative){
        if(!relative.startsWith("/")||relative.startsWith("//")||relative.contains("\\")||relative.contains(".."))relative="/football.html";
        Intent i=new Intent(this,MainActivity.class).setAction(Intent.ACTION_VIEW).setData(Uri.parse(ORIGIN+relative));
        return PendingIntent.getActivity(this,relative.hashCode(),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    private void showScore(JSONObject o){
        if(!canNotify())return;
        String home=o.optString("home","Home"),away=o.optString("away","Away"),phase=o.optString("phase","LIVE"),eventId=o.optString("eventId","");
        int h=o.optInt("homeScore",-1),a=o.optInt("awayScore",-1);
        if(h<0||a<0||h>99||a>99||home.length()>45||away.length()>45||eventId.length()<8||eventId.length()>110)return;
        if(!("LIVE".equals(phase)||"FT".equals(phase)))return;
        String last=getPreferences(MODE_PRIVATE).getString("last_event","");
        if(eventId.equals(last))return;
        getPreferences(MODE_PRIVATE).edit().putString("last_event",eventId).apply();
        String score=home+"  "+h+" : "+a+"  "+away;
        String label="FT".equals(phase)?"FULL TIME":"LIVE MATCH UPDATE";
        String detail=o.optString("detail","");if(detail.length()>75)detail=detail.substring(0,75);
        String relative=o.optString("href","/football.html");
        if(!relative.matches("^/match\\.html\\?league=[a-zA-Z0-9.]+&event=[0-9]+$"))relative="/football.html";
        // Plain text like a live-score alert: no custom scoreboard or attached image.
        // Display the verified scorer when the football feed supplies one.
        String title=home+" "+h+"–"+a+" "+away;
        String body="FT".equals(phase)?"Full time"+(detail.isEmpty()?"":" • "+detail)
              :detail.isEmpty()?"Goal / score update • Scorer unavailable":detail;
        NotificationCompat.Builder b=new NotificationCompat.Builder(this,SCORES)
          .setSmallIcon(R.drawable.ic_stat_fdytxl).setColor(Color.rgb(232,49,93))
          .setContentTitle(title).setContentText(body)
          .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
          .setAutoCancel(true).setContentIntent(openLink(relative)).setPriority(NotificationCompat.PRIORITY_DEFAULT);
        try{NotificationManagerCompat.from(this).notify(eventId.hashCode(),b.build());}catch(SecurityException ignored){}
    }
    private void notifyGeneral(String title,String body){
        NotificationCompat.Builder b=new NotificationCompat.Builder(this,GENERAL)
          .setSmallIcon(R.drawable.ic_stat_fdytxl).setColor(Color.rgb(232,49,93))
          .setContentTitle(title).setContentText(body).setStyle(new NotificationCompat.BigTextStyle().bigText(body))
          .setAutoCancel(true).setContentIntent(openLink("/settings.html#android-notifications"));
        try{NotificationManagerCompat.from(this).notify(95015,b.build());}catch(SecurityException ignored){}
    }
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grants){
        super.onRequestPermissionsResult(requestCode,permissions,grants);
        if(requestCode==REQ_NOTIFICATION && onboardingNotificationRequest){
            onboardingNotificationRequest=false;
            showLocationChoice();
        }
        if(requestCode==REQ_NOTIFICATION && pendingPushPermission){
            pendingPushPermission=false;
            if(grants.length>0&&grants[0]==PackageManager.PERMISSION_GRANTED)activatePush();
            else Toast.makeText(this,"Background football notifications stay off until permission is granted",Toast.LENGTH_LONG).show();
        }
        if(requestCode==REQ_LOCATION && geoCallback!=null){
            boolean granted=grants.length>0&&grants[0]==PackageManager.PERMISSION_GRANTED;
            geoCallback.invoke(geoOrigin,granted,false);geoCallback=null;geoOrigin=null;
        }
    }
    @Override protected void onNewIntent(Intent intent){
        super.onNewIntent(intent);
        Uri uri=intent.getData();if(uri!=null&&isOurs(uri)&&web!=null)web.loadUrl(uri.toString());
    }
    @Override public void onBackPressed(){
        if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();
    }
    @Override protected void onSaveInstanceState(Bundle b){super.onSaveInstanceState(b);web.saveState(b);}
    @Override protected void onDestroy(){if(web!=null){web.destroy();web=null;}super.onDestroy();}
}
