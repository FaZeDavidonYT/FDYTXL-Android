package com.fdytxl.android;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.GeolocationPermissions;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.net.http.SslError;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.RemoteViews;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONObject;
import java.util.Collections;

public class MainActivity extends Activity {
    private static final String ORIGIN = "https://fdytxl-fdytxl-0606.wix-site-host.com";
    private static final int REQ_NOTIFICATION=501, REQ_LOCATION=502;
    private static final String SCORES="fdytxl_live_scores", GENERAL="fdytxl_updates";
    private WebView web;
    private ProgressBar loading;
    private GeolocationPermissions.Callback geoCallback;
    private String geoOrigin;

    @SuppressLint("SetJavaScriptEnabled")
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(Color.rgb(16, 12, 18));
        getWindow().setNavigationBarColor(Color.rgb(16, 12, 18));
        FrameLayout root = new FrameLayout(this);
        web = new WebView(this);
        loading = new ProgressBar(this);
        FrameLayout.LayoutParams spinner = new FrameLayout.LayoutParams(120,120,Gravity.CENTER);
        root.addView(web,new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(loading, spinner);
        setContentView(root);
        makeChannels();

        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setGeolocationEnabled(true);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSupportMultipleWindows(false);
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O) s.setSafeBrowsingEnabled(true);
        android.webkit.CookieManager.getInstance().setAcceptCookie(true);

        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request){
                Uri uri=request.getUrl();
                if(isOurs(uri))return false;
                if("https".equals(uri.getScheme()) || "mailto".equals(uri.getScheme())){
                    try{startActivity(new Intent(Intent.ACTION_VIEW,uri));}catch(Exception ignored){}
                }
                return true;
            }
            @Override public void onPageFinished(WebView view,String url){loading.setVisibility(View.GONE);}
            @Override public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error){handler.cancel();}
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public void onGeolocationPermissionsShowPrompt(String origin,GeolocationPermissions.Callback callback){
                // Only the FDYTXL weather website can ask for foreground approximate location.
                if(!ORIGIN.equals(origin)){callback.invoke(origin,false,false);return;}
                if(ContextCompat.checkSelfPermission(MainActivity.this,Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED){
                    callback.invoke(origin,true,false);return;
                }
                if(geoCallback!=null){geoCallback.invoke(geoOrigin,false,false);}
                geoCallback=callback;geoOrigin=origin;
                requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},REQ_LOCATION);
            }
            @Override public void onGeolocationPermissionsHidePrompt(){
                geoCallback=null;geoOrigin=null;
            }
        });
        // AndroidX WebMessageListener is restricted to this HTTPS origin and main frame.
        // Unlike addJavascriptInterface, an untrusted iframe cannot request notifications.
        if(WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)){
            WebViewCompat.addWebMessageListener(web,"FDYTXLAndroid",Collections.singleton(ORIGIN),
              (view,message,sourceOrigin,isMainFrame,reply)->{
                if(!isMainFrame || !ORIGIN.equals(sourceOrigin.toString()))return;
                String json=message.getData();
                if(json==null || json.length()>2500)return;
                runOnUiThread(()->handleSiteMessage(json));
              });
        }
        if(saved==null){
            web.loadUrl(ORIGIN + "/");
        }else web.restoreState(saved);
    }
    private boolean isOurs(Uri uri){return "https".equals(uri.getScheme())&&"fdytxl-fdytxl-0606.wix-site-host.com".equals(uri.getHost());}
    private void handleSiteMessage(String data){
        try{
            JSONObject obj=new JSONObject(data);
            String type=obj.optString("type","");
            if("permission".equals(type)){askNotifications();return;}
            if("test".equals(type)){
                if(canNotify()) notifyGeneral("FDYTXL • Demo notification","This is a DEMO notification, not a real football score.");
                else Toast.makeText(this,"Enable notifications in Android settings first",Toast.LENGTH_LONG).show();
                return;
            }
            if("score".equals(type)) showScore(obj);
        }catch(Exception ignored){}
    }
    private void askNotifications(){
        if(Build.VERSION.SDK_INT>=33 && ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_NOTIFICATION);
        }else Toast.makeText(this,"Notification setting is controlled by Android",Toast.LENGTH_SHORT).show();
    }
    private boolean canNotify(){
        return (Build.VERSION.SDK_INT<33||ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED)
               &&NotificationManagerCompat.from(this).areNotificationsEnabled();
    }
    private void makeChannels(){
        if(Build.VERSION.SDK_INT>=26){
            NotificationManager manager=getSystemService(NotificationManager.class);
            NotificationChannel score=new NotificationChannel(SCORES,"FDYTXL Live Football",NotificationManager.IMPORTANCE_DEFAULT);
            score.setDescription("Real score changes detected while FDYTXL is open");
            NotificationChannel other=new NotificationChannel(GENERAL,"FDYTXL Website",NotificationManager.IMPORTANCE_DEFAULT);
            other.setDescription("Opt-in FDYTXL app test and website notifications");
            manager.createNotificationChannel(score);manager.createNotificationChannel(other);
        }
    }
    private PendingIntent openLink(String relative){
        if(!relative.startsWith("/")||relative.startsWith("//")||relative.contains("\\")||relative.contains(".."))relative="/football.html";
        Intent i=new Intent(this,MainActivity.class).setAction(Intent.ACTION_VIEW).setData(Uri.parse(ORIGIN+relative));
        return PendingIntent.getActivity(this,relative.hashCode(),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    private void showScore(JSONObject o){
        if(!canNotify())return;
        String home=o.optString("home","Home"),away=o.optString("away","Away"),phase=o.optString("phase","LIVE"),eventId=o.optString("eventId","");
        int h=o.optInt("homeScore",-1),a=o.optInt("awayScore",-1);
        if(h<0||a<0||h>99||a>99||home.length()>45||away.length()>45||eventId.length()<8||eventId.length()>110)return;
        if(!("LIVE".equals(phase)||"FT".equals(phase)))return;
        String last=getPreferences(MODE_PRIVATE).getString("last_event","");
        if(eventId.equals(last))return;
        getPreferences(MODE_PRIVATE).edit().putString("last_event",eventId).apply();
        String score=home+"  "+h+" : "+a+"  "+away;
        String label="FT".equals(phase)?"FULL TIME":"LIVE MATCH UPDATE";
        String detail=o.optString("detail","");if(detail.length()>75)detail=detail.substring(0,75);
        String relative=o.optString("href","/football.html");
        if(!relative.matches("^/match\\.html\\?league=[a-zA-Z0-9.]+&event=[0-9]+$"))relative="/football.html";
        RemoteViews expanded=new RemoteViews(getPackageName(),R.layout.notification_score);
        expanded.setTextViewText(R.id.score_home,home);
        expanded.setTextViewText(R.id.score_away,away);
        expanded.setTextViewText(R.id.score_count,h+" : "+a);
        expanded.setTextViewText(R.id.score_phase,label);
        expanded.setTextViewText(R.id.score_detail,detail);
        NotificationCompat.Builder b=new NotificationCompat.Builder(this,SCORES)
          .setSmallIcon(R.drawable.ic_score).setColor(Color.rgb(232,49,93))
          .setContentTitle("FDYTXL ⚽ "+label)
          .setContentText(score).setStyle(new NotificationCompat.DecoratedCustomViewStyle())
          .setCustomBigContentView(expanded)
          .setAutoCancel(true).setContentIntent(openLink(relative)).setPriority(NotificationCompat.PRIORITY_DEFAULT);
        try{NotificationManagerCompat.from(this).notify(eventId.hashCode(),b.build());}catch(SecurityException ignored){}
    }
    private void notifyGeneral(String title,String body){
        NotificationCompat.Builder b=new NotificationCompat.Builder(this,GENERAL)
          .setSmallIcon(R.drawable.ic_score).setColor(Color.rgb(232,49,93))
          .setContentTitle(title).setContentText(body).setStyle(new NotificationCompat.BigTextStyle().bigText(body))
          .setAutoCancel(true).setContentIntent(openLink("/settings.html#android-notifications"));
        try{NotificationManagerCompat.from(this).notify(95015,b.build());}catch(SecurityException ignored){}
    }
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grants){
        super.onRequestPermissionsResult(requestCode,permissions,grants);
        if(requestCode==REQ_LOCATION && geoCallback!=null){
            boolean granted=grants.length>0&&grants[0]==PackageManager.PERMISSION_GRANTED;
            geoCallback.invoke(geoOrigin,granted,false);geoCallback=null;geoOrigin=null;
        }
    }
    @Override protected void onNewIntent(Intent intent){
        super.onNewIntent(intent);
        Uri uri=intent.getData();if(uri!=null&&isOurs(uri)&&web!=null)web.loadUrl(uri.toString());
    }
    @Override public void onBackPressed(){
        if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();
    }
    @Override protected void onSaveInstanceState(Bundle b){super.onSaveInstanceState(b);web.saveState(b);}
    @Override protected void onDestroy(){if(web!=null){web.destroy();web=null;}super.onDestroy();}
}
